#DEFINE TIME_ZONE_SIZE  172
#DEFINE TIME_ZONE_ID_UNKNOWN     0
#DEFINE TIME_ZONE_ID_STANDARD    1
#DEFINE TIME_ZONE_ID_DAYLIGHT    2

DECLARE INTEGER GetTimeZoneInformation IN kernel32.dll;
    STRING @ lpTimeZoneInformation

*| typedef struct _TIME_ZONE_INFORMATION {
*|     LONG       Bias;                  0        4
*|     WCHAR      StandardName[ 32 ];    4       64
*|     SYSTEMTIME StandardDate;         68       16
*|     LONG       StandardBias;         84        4
*|     WCHAR      DaylightName[ 32 ];   88       64
*|     SYSTEMTIME DaylightDate;        152       16
*|     LONG       DaylightBias;        168        4
*| } TIME_ZONE_INFORMATION, *PTIME_ZONE_INFORMATION; total 172 bytes

LOCAL cBuffer, nResult
cBuffer = Repli(Chr(0), TIME_ZONE_SIZE)
nResult = GetTimeZoneInformation(@cBuffer)

DO CASE
CASE nResult = TIME_ZONE_ID_STANDARD
    ? "StandardDate member"
CASE nResult = TIME_ZONE_ID_DAYLIGHT
    ? "DaylightDate member"
CASE nResult = TIME_ZONE_ID_UNKNOWN
    ? "The system cannot determine the current time zone"
OTHER
    ? "The Time Zone ID is invalid"
ENDCASE
?
? "Bias (minutes between UTC and local):", buf2dword(SUBSTR(cBuffer, 1,4))
? "Standard Bias:", buf2dword(SUBSTR(cBuffer, 85,4))
? "Daylight Bias:", buf2dword(SUBSTR(cBuffer, 169,4))
?
? "Standard name:", STRTRAN(SUBSTR(cBuffer, 5,64), Chr(0),"")
? "Daylight name:", STRTRAN(SUBSTR(cBuffer, 89,64), Chr(0),"")
?
? "Standard Date:",;
    buf2word(SUBSTR(cBuffer,69,2)),;
    buf2word(SUBSTR(cBuffer,71,2)),;
    buf2word(SUBSTR(cBuffer,73,2)),;
    buf2word(SUBSTR(cBuffer,75,2)),;
    buf2word(SUBSTR(cBuffer,77,2)),;
    buf2word(SUBSTR(cBuffer,79,2))

? "Daylight Date:",;
    buf2word(SUBSTR(cBuffer,153,2)),;
    buf2word(SUBSTR(cBuffer,155,2)),;
    buf2word(SUBSTR(cBuffer,157,2)),;
    buf2word(SUBSTR(cBuffer,159,2)),;
    buf2word(SUBSTR(cBuffer,161,2)),;
    buf2word(SUBSTR(cBuffer,163,2))

FUNCTION buf2dword(lcBuffer)
RETURN Asc(SUBSTR(lcBuffer, 1,1)) + ;
    BitLShift(Asc(SUBSTR(lcBuffer, 2,1)),  8) +;
    BitLShift(Asc(SUBSTR(lcBuffer, 3,1)), 16) +;
    BitLShift(Asc(SUBSTR(lcBuffer, 4,1)), 24)

FUNCTION buf2word(lcBuffer)
RETURN Asc(SUBSTR(lcBuffer, 1,1)) + ;
       Asc(SUBSTR(lcBuffer, 2,1)) * 256 
