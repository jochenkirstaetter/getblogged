Clear

*#beautify keyword_nochange
* see http://support.microsoft.com/kb/894818/

Declare Integer MessageBoxA In user32 As MessageBoxA;
	Integer, String, ;
	String, Integer

Declare Integer MessageBoxTimeoutA In User32 As MessageBoxTimeoutA ;
	Integer, String, ;
	String, Integer, ;
	Integer, Integer
*#beautify

#Define WM_HELP			0x0053
#Define MB_DEFBUTTON4	0x00000300     && Fourth button is default
#Define MB_HELP			0x00004000
#Define Messagebox		MessageBoxHelp

oWM = Createobject("WindowsMessage")
Bindevent(0, WM_HELP, oWM, "OnHelp")
? Messagebox("Das ist eine Testaussage mit Hilfe-Button.\n\r\tCooles Feature, oder?", 3+32+MB_HELP, "MessageBox")
? Messagebox("Und jetzt auch mal mit Timeout.\n\r\tCooles Feature, oder?", 3+32+MB_DEFBUTTON4+MB_HELP, "MessageBox",5000)

Function MessageBoxHelp(eMessageText, nDialogBoxType, cTitleBarText, nTimeout)
	Local liResponse
	*----------------------------------------------------------------------
	* Defensive Programmierung
	*----------------------------------------------------------------------
	eMessageText = Transform(Evl(eMessageText,""))
	nDialogBoxType = Max(Int(Val(Transform(Evl(nDialogBoxType,0)))),0)
	cTitleBarText = Transform(Evl(cTitleBarText,""))
	nTimeout = Max(Int(Val(Transform(Evl(nTimeout,0)))),0)

	*----------------------------------------------------------------------
	* Parse Escape-Sequenzen
	*----------------------------------------------------------------------
	eMessageText = Strtran(eMessageText, "\n", Chr(13)+Chr(10), 1, -1, 1+2)
	eMessageText = Strtran(eMessageText, "\r", Chr(13)+Chr(10), 1, -1, 1+2)
	eMessageText = Strtran(eMessageText, "\t", Chr(9), 1, -1, 1+2)
	If Pcount() < 4
		m.liResponse = MessageBoxA(_VFP.HWnd, eMessageText, cTitleBarText, nDialogBoxType)
	Else
		m.liResponse = MessageBoxTimeoutA(_VFP.HWnd, eMessageText, cTitleBarText, nDialogBoxType, 0, nTimeout)
		*----------------------------------------------------------------------
		* Handle Timeout-Value gem�� VFP-Hilfe.
		*----------------------------------------------------------------------
		m.liResponse = Iif(m.liResponse > 7, -1, m.liResponse)
	Endif
	Return m.liResponse
Endfunc

Define Class WindowsMessage As Relation
	Procedure OnHelp(nHWND As Number, nMessage As Number, nParameters1 As Number, nParameters2 As Number) As Integer
		? "Hilfe wurde ausgel�st!"
	Endproc
Enddefine
