*-- API-Funktion
Declare SHORT GetVolumeInformation In KERNEL32.Dll As GetHDInfo ;
    STRING lpRootPathName, ;
    STRING @lpVolumeNameBuffer, ;
    INTEGER nVolumeNameSize, ;
    INTEGER @lpVolumeSerialNumber, ;
    INTEGER @lpMaximumComponentLength, ;
    INTEGER @lpFileSystemFlags, ;
    STRING @lpFileSystemNameBuffer, ;
    INTEGER nFileSystemNameSize

*-- Parameter deklarieren
lpRootPathName = "C:\" && address of root directory of the file system
lpVolumeNameBuffer = Space( 255 ) && address of name of the volume
nVolumeNameSize = 254 && length of lpVolumeNameBuffer
lpVolumeSerialNumber = 0 && address of volume serial number
lpMaximumComponentLength = 254 && address of system's maximum filename length
lpFileSystemFlags = 0 && address of file system flags
lpFileSystemNameBuffer = Space( 255 ) && address of name of file system
nFileSystemNameSize = 254 && length of lpFileSystemNameBuffer

*-- und abfragen
If GetHDInfo( ;
        lpRootPathName, ;
        @lpVolumeNameBuffer, ;
        nVolumeNameSize, ;
        @lpVolumeSerialNumber, ;
        @lpMaximumComponentLength, ;
        @lpFileSystemFlags, ;
        @lpFileSystemNameBuffer, ;
        nFileSystemNameSize ) > 0

    *-- Festinformationen
    ? "Volume-Label: " + Left( lpVolumeNameBuffer, At( Chr( 0 ), lpVolumeNameBuffer ) - 1 )
    ? "Volume-Serien-Num.: " + Transform( lpVolumeSerialNumber )
    ? "Dateinamensl�nge: " + Transform( lpMaximumComponentLength )
    ? "Datei-System-Flags: " + Transform( lpFileSystemFlags )
    ? "Datei-System: " + Left( lpFileSystemNameBuffer, At( Chr( 0 ), lpFileSystemNameBuffer ) - 1 )

Else

    *-- Fehlermeldung ausgeben
    Wait Window "Es ist ein Fehler aufgetreten"

Endif

