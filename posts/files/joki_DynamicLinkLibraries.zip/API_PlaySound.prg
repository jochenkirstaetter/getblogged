
*#beautify keyword_nochange
* see http://support.microsoft.com/kb/894818/

Declare Integer PlaySound In WinMM.dll ;
	String, Integer, ;
	Integer
*#beautify

#Define SND_APPLICATION 80         && look for application specific association
#Define SND_ALIAS 10000     && name is a WIN.INI [sounds] entry
#Define SND_ALIAS_ID 110000    && name is a WIN.INI [sounds] entry identifier
#Define SND_ASYNC 1         && play asynchronously
#Define SND_FILENAME 20000     && name is a file name
#Define SND_LOOP 8         && loop the sound until next sndPlaySound
#Define SND_MEMORY 4         && lpszSoundName points to a memory file
#Define SND_NODEFAULT 2         && silence not default, if sound not found
#Define SND_NOSTOP 10        && don't stop any currently playing sound
#Define SND_NOWAIT 2000      && don't wait if the driver is busy
#Define SND_PURGE 40               && purge non-static events for task
#Define SND_RESOURCE 40004     && name is a resource name or atom
#Define SND_SYNC 0         && play synchronously (default)

*---	Use external wave file to play.
? PlaySound("C:\Windows\Media\tada.wav", 0, SND_ASYNC)

*---	Use alias to play.
? PlaySound("SystemExit"+Chr(0), 0, SND_ASYNC)
