Declare Integer MoveFile in kernel32 string cExistingFileName, string

md c:\temp
md c:\temp\Folder_old

a=Movefile("c:\temp\Folder_old","c:\temp\Folder_New")
=Messagebox(Iif(A<>0,"Success","Failure")

return
