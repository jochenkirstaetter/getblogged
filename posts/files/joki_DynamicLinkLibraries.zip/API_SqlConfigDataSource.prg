Clear

*-- Deklarieren der API-Methode zum Anlegen/Modifizieren/L�schen einer ODBC-Verbindung.
DECLARE INTEGER SQLConfigDataSource IN ODBCCP32.DLL ;
			INTEGER hwndParent, ;
			INTEGER fRequest, ;
			STRING lpszDriver, ;
			STRING lpszAttributes

Declare Integer ConfigDSNW IN sqlsrv32 ;
			INTEGER hwndParent, ;
			INTEGER fRequest, ;
			STRING lpszDriver, ;
			STRING lpszAttributes

lnType = 4
lcOdbcDriver = "SQL Server"
lcDSN_Attributes = ;
	"DSN=HS_CR" + Chr(0) + ;
	"Description=HS Process - Useraccount Crystal Reports XI" + Chr(0) + ;
	"Server=HERKULES" + Chr(0) + ;
	"Database=HS" + Chr(0) + ;
	Chr(0)

? Datetime()
? SQLConfigDataSource(0, m.lnType, lcODBCDriver, lcDSN_Attributes)

? ConfigDSNW(0, m.lnType + 1, lcODbcDriver, ;
	Strconv("DSN=HS_CR"+Chr(0)+"DATABASE=HS"+Chr(0)+"UID=HS"+Chr(0)+"PWD=geheim"+Chr(0)+Chr(0),5))
