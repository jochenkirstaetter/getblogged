Declare Integer URLDownloadToFile In UrlMon.dll ;
	Integer, String, ;
	String, Integer, ;
	Integer

? URLDownloadToFIle(0, "http://www.afpages.de/download/AFP_3.0.600.zip", "D:\Download\Test.zip", 0, 0)
