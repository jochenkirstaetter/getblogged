*-- stapel.prg

Local lcCommandLine, lcProcessInfo, lcStartupInfo
lcCommandLine = "stapel.cmd"

Declare Integer GetLastError ;
	IN WIN32API

Declare Integer CreateProcess ;
	IN WIN32API ;
	String lpApplication, ;
	String @lpCommandLine, ;
	Integer lpProcessAttributes, ;
	Integer lpThreadAttributes, ;
	Integer bInheritHandles, ;
	Integer dwCreationFlags, ;
	String lpEnvironment, ;
	String lpCurrentDirectory, ;
	String lpStartupInfo, ;
	String @lpProcessInformation

Declare Integer WaitForSingleObject ;
	IN WIN32API ;
	Integer nHandle, ;
	Integer dwMilliseconds

Declare Integer CloseHandle ;
	IN WIN32API ;
	Integer nHandle

lcCommandLine = lcCommandLine + Chr(0)
lcProcessInfo = Replicate(Chr(0),16)
lcStartupInfo =
BinToC(68,"RS")+Replicate(Chr(0),40)+BinToC(1,"RS")+Replicate(Chr(0),20)

If
	0!=CreateProcess(Null,@lcCommandLine,0,0,0,0,Null,Null,lcStartupInfo,@lcProc
	essInfo)
	Local lnProcess
	lnProcess = CToBin(Substr(lcProcessInfo,1,4),"RS")
	? "Running",Left(lcCommandLine,Max(0,At(Chr(0),lcCommandLine)-1))
	Do While 258=WaitForSingleObject(lnProcess,100)
		?? "."
		DoEvents
	Enddo
	?? "ok"
	? ""
	CloseHandle(lnProcess)
	CloseHandle(CToBin(Substr(lcProcessInfo,5,4),"RS"))
Else
	Error "CreateProcess() failed with error "+Transform(GetLastError())
Endif

*-- end
