DECLARE INTEGER GetLongPathName IN KERNEL32 ;
	STRING @lpszShortPath, STRING @lpszLongPath, ;
	INTEGER cchBuffer 
 
 *lcShortPath = "C:\Progra~1" 
 lcShortPath = "C:\Dokume~1" 
 lcLongPath = SPACE( 200 ) 
 
 *-- Langen Pfadnamen holen 
 GetLongPathName( @lcShortPath, @lcLongPath, 199 ) 
 
 *-- CHR( 0 ) entfernen 
 ? CHRTRAN( lcLongPath, CHR( 0 ), '' ) 